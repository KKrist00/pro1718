package examen;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;

import modelo.Libro;

public class Metodos {


//EJERCICIO1
	
	public char metodo1(int numero) {
		
		final String JuegoCaracteres="TRWAGMYFPDXBNJZSQVHLCKE";
		
		Scanner Teclado = new Scanner(System.in);
		
		int DNI = 0;
		
		int Posicion = 0;
		
		char Letra = 0;
		
		for (int i = 0; i < 8; i++) {
			
			
		if (DNI < 0|| DNI >9) {
			
			
		System.out.println("�Dime Tu" + i +"DNI?.");
			
		DNI = Teclado.nextInt();
		
		DNI++;
		  
		Posicion = DNI - (DNI/23) * 23;
		
		 Letra = JuegoCaracteres.charAt(Posicion);
		
		System.out.println("Tu letra del DNI." + DNI + Letra);
		
		
	}
		}
		
		return Letra;

		}


	// EJERCICIO 2
	
	 public Libro[] metodo2(String[] libros) {
		 
		 String[] Libros ={"2#EL QUIJOTE DE LA MANCHA#16.25","X#LOS PILARES DE LA TIERRA#18.50",
				 "2#ODISEA EN EL ESPACIO#16.X",
				 "5#LOS PILARES DE LA TIERRA#18.50"};
		 
		 ArrayList<Libro> stock = new ArrayList<Libro>();
		 
		 try {
			 
			 for (String libro : libros) {
		 
				
				String titulo = libro.split("#")[0];
				
				float precio = Float.parseFloat(libro.split("#")[1]);
				
				Libro objLibro = new Libro(0,titulo, precio);
				
				stock.add(objLibro);
				
			 	}	
			
		 
			}catch (NullPointerException e) {
				
			}
		return null;

		}

				
	// EJERCICIO 3
	 

	 public void generaAleatorios(int cuantos, int inferior, int superior){

			for (int i = 0; i < cuantos; i++)
				
				System.out.println(inferior + (int) (Math.random() * (superior - inferior + 1)));

		}

	

	
	 public int[][] metodo3(int jugadores, int partidas){
		 
		
			
		return null;
		 
		 
	 }

		
}
