package examen;

import modelo.Libro;

public class Metodos {

	// ejercicio 1

	// ejercicio 2
	
	// ejercicio 3
	

	
		

	
}
